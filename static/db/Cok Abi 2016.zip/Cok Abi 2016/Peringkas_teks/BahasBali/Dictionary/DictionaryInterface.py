class DictionaryInterface(object):
    """description of class"""

    def contains(self, word):
        pass



