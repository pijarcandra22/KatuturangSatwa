class ContextInterface(object):
    """description of class"""

    def getOriginalWord(self):
        pass

    def setCurrentWord(self, word):
        pass

    def getCurrentWord(self):
        pass

    def getDictionary(self):
        pass

    def stopProcess(self):
        pass

    def processIsStopped(self):
        pass

    def addRemoval(self, removal):
        pass

    def getRemovals(self):
        pass




