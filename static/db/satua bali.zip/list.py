import re

list = []
with open("list.txt", encoding="utf8") as file:
    for i in file:
        list.append(i)

pattern = r'">(.*?)</a>'

out = []
for i in list:
    s = i
    substring = re.search(pattern, s).group(1)
    print(substring)
