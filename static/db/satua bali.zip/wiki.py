import wikipedia
wikipedia.set_lang("ban")

list = []
with open("list.txt", encoding="utf8") as file:
    for i in file:
        list.append(i)

for index, i in enumerate(list):
    satua = i.strip()

    page = wikipedia.page(satua)

    with open(satua + ".txt", "w", encoding="utf-8") as output:
        output.write(page.content)

    content = []
    with open(satua + ".txt", encoding="utf-8") as file:
        for i in file:
            content.append(i)
        content = content[4:-2]

    out = []
    for i in content:
        if i != "\n":
            out.append(i)

    with open(satua + ".txt", "w", encoding="utf-8") as output:
        output.write("".join(out))

    print(index, "/", len(list))
